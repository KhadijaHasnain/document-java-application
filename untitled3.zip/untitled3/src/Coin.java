public class Coin extends Finding {
    private double diameter;

    public Coin(int id, double latitude, double longitude, int personId, String dateFound, int yearEstimated, Integer museumId, String material, double diameter) {
        super(id, latitude, longitude, personId, dateFound, yearEstimated, museumId, "Coin", material);
        this.diameter = diameter;
    }

    public double getDiameter() {
        return diameter;
    }

    public void setDiameter(double diameter) {
        this.diameter = diameter;
    }

    @Override
    public String toString() {
        return "Coin{" +
                "diameter=" + diameter +
                ", " + super.toString() +
                '}';
    }
}
