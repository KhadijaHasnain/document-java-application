// Finding.java
public class Finding {
    private int id;
    private double latitude;
    private double longitude;
    private int personId;
    private String dateFound;
    private int yearEstimated;
    private Integer museumId;
    private String type;
    private String material;

    public Finding(int id, double latitude, double longitude, int personId, String dateFound, int yearEstimated, Integer museumId, String type, String material) {
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.personId = personId;
        this.dateFound = dateFound;
        this.yearEstimated = yearEstimated;
        this.museumId = museumId;
        this.type = type;
        this.material = material;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }

    public int getPersonId() { return personId; }
    public void setPersonId(int personId) { this.personId = personId; }

    public String getDateFound() { return dateFound; }
    public void setDateFound(String dateFound) { this.dateFound = dateFound; }

    public int getYearEstimated() { return yearEstimated; }
    public void setYearEstimated(int yearEstimated) { this.yearEstimated = yearEstimated; }

    public Integer getMuseumId() { return museumId; }
    public void setMuseumId(Integer museumId) { this.museumId = museumId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getMaterial() { return material; }
    public void setMaterial(String material) { this.material = material; }

    @Override
    public String toString() {
        return "Finding{" +
                "id=" + id +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", personId=" + personId +
                ", dateFound='" + dateFound + '\'' +
                ", yearEstimated=" + yearEstimated +
                ", museumId=" + museumId +
                ", type='" + type + '\'' +
                ", material='" + material + '\'' +
                '}';
    }
}
