import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseConnector {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/l"; // Change the URL according to your DB configuration
        String user = "root"; // Change to your DB username
        String password = "musa12"; // Change to your DB password
        String filePath = "C:\\Users\\musa\\Downloads\\funn.txt"; // Corrected file path

        try (BufferedReader br = new BufferedReader(new FileReader(filePath));
             Connection conn = DriverManager.getConnection(url, user, password)) {

            // Disable auto-commit for batch processing
            conn.setAutoCommit(false);

            // Prepare SQL statements
            String personSQL = "INSERT INTO Persons (id, name, phone, email) VALUES (?, ?, ?, ?)";
            String museumSQL = "INSERT INTO Museums (id, name, location) VALUES (?, ?, ?)";
            String findingSQL = "INSERT INTO Findings (id, latitude, longitude, person_id, date_found, identifier, quantity, type, material, weight) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Read the file and insert data
            String line;
            int section = 0;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }
                switch (line) {
                    case "Personer:":
                        section = 1;
                        break;
                    case "Museer:":
                        section = 2;
                        break;
                    case "Funn:":
                        section = 3;
                        break;
                    default:
                        switch (section) {
                            case 1:
                                insertPerson(conn, personSQL, line, br);
                                break;
                            case 2:
                                insertMuseum(conn, museumSQL, line, br);
                                break;
                            case 3:
                                insertFinding(conn, findingSQL, line, br);
                                break;
                        }
                        break;
                }
            }

            // Commit the transaction
            conn.commit();

        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertPerson(Connection conn, String sql, String idLine, BufferedReader br) throws IOException, SQLException {
        int id = Integer.parseInt(idLine);
        String name = br.readLine().trim();
        String phone = br.readLine().trim();
        String email = br.readLine().trim();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, phone);
            pstmt.setString(4, email);
            pstmt.executeUpdate();
        }
    }

    private static void insertMuseum(Connection conn, String sql, String idLine, BufferedReader br) throws IOException, SQLException {
        int id = Integer.parseInt(idLine);
        String name = br.readLine().trim();
        String location = br.readLine().trim();

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, location);
            pstmt.executeUpdate();
        }
    }

    private static void insertFinding(Connection conn, String sql, String idLine, BufferedReader br) throws IOException, SQLException {
        int id = Integer.parseInt(idLine);
        double latitude = Double.parseDouble(br.readLine().trim());
        double longitude = Double.parseDouble(br.readLine().trim());
        int personId = Integer.parseInt(br.readLine().trim());
        String dateFound = br.readLine().trim();
        int identifier = Integer.parseInt(br.readLine().trim());
        int quantity = Integer.parseInt(br.readLine().trim());
        String type = br.readLine().trim();
        String material = br.readLine().trim();
        double weight = Double.parseDouble(br.readLine().trim());

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setDouble(2, latitude);
            pstmt.setDouble(3, longitude);
            pstmt.setInt(4, personId);
            pstmt.setString(5, dateFound);
            pstmt.setInt(6, identifier);
            pstmt.setInt(7, quantity);
            pstmt.setString(8, type);
            pstmt.setString(9, material);
            pstmt.setDouble(10, weight);
            pstmt.executeUpdate();
        }
    }
}
