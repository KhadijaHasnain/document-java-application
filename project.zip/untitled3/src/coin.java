public class coin {
}
